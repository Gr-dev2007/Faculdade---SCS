import java.security.MessageDigest;
import java.util.Scanner;

public class HashFunction {
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite uma mensagem: ");
        String message = scanner.nextLine();
        scanner.close();

        // Criando um hash com SHA-256
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(message.getBytes());

        // Convertendo bytes para formato hexadecimal
        StringBuilder hexString = new StringBuilder();
        for (byte b : hash) {
            hexString.append(String.format("%02x", b));
        }

        System.out.println("Hash SHA-256: " + hexString.toString());
    }
}
