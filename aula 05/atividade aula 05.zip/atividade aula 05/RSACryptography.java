import java.security.*;
import javax.crypto.Cipher;
import java.util.Base64;

public class RSACryptography {
    public static void main(String[] args) throws Exception {
        // Gerando o par de chaves RSA
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
        keyGen.initialize(2048); // Tamanho da chave
        KeyPair keyPair = keyGen.generateKeyPair();
        PublicKey publicKey = keyPair.getPublic();
        PrivateKey privateKey = keyPair.getPrivate();

        // Mensagem a ser criptografada
        String message = "Mensagem Confidencial";

        // Criptografando com a chave pública
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.ENCRYPT_MODE, publicKey);
        byte[] encryptedBytes = cipher.doFinal(message.getBytes());
        String encryptedMessage = Base64.getEncoder().encodeToString(encryptedBytes);
        System.out.println("Texto Criptografado: " + encryptedMessage);

        // Descriptografando com a chave privada
        cipher.init(Cipher.DECRYPT_MODE, privateKey);
        byte[] decryptedBytes = cipher.doFinal(encryptedBytes);
        System.out.println("Texto Descriptografado: " + new String(decryptedBytes));
    }
}
