import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import java.util.Base64;

public class AESCryptography {
    public static void main(String[] args) throws Exception {
        // Gerando uma chave AES
        KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
        keyGenerator.init(128); // Tamanho da chave: 128 bits
        SecretKey secretKey = keyGenerator.generateKey();

        // Texto a ser criptografado
        String text = "Mensagem Secreta";

        // Criptografando
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, secretKey);
        byte[] encryptedText = cipher.doFinal(text.getBytes());

        // Convertendo para Base64 para exibição
        String encryptedBase64 = Base64.getEncoder().encodeToString(encryptedText);
        System.out.println("Texto Criptografado: " + encryptedBase64);

        // Descriptografando
        cipher.init(Cipher.DECRYPT_MODE, secretKey);
        byte[] decryptedText = cipher.doFinal(encryptedText);
        System.out.println("Texto Descriptografado: " + new String(decryptedText));
    }
}